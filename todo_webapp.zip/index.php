<?php
	
	include "LoginController.php";
	
	$l_controller = new LoginController();
?>

<html>
	
	<head>
		
		<title>Login | To-Do</title>
		
		<link href='https://fonts.googleapis.com/css?family=Bebas Neue' rel='stylesheet'>
		
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		
		<link rel="stylesheet" href="style.css">
		
	</head>
	
	<body>
		
		<h1 class="headercenter">To-Do List Application</h1>
		
		<section class="login">
			
			<?php
				
				if(array_key_exists('submitCreate', $_POST)) {
					
					$l_controller->createUser();
				}
				
				if(array_key_exists('submitLogin', $_POST)) {
					
					$l_controller->loginUser();
				}
			?>
			
			<!--<form action="connection.php" method="post">-->
			<form method="post">
				
				<br/>
				
				<input type="text" name="user" placeholder="Username"/>
				
				<br/>
				
				<input type="password" name="pass" placeholder="Password"/>
				
				<br/>
				
				<button class="loginbutton" type="submit" name="submitLogin">Log in</button>
				
				<br/>
				
				<button class="loginbutton" type="submit" name="submitCreate">Create Account</button>
				
				<br/>
				
			</form>
			
		</section>
		
		<footer>
			
			
			
		</footer>
		
		<!-- jQuery, Popper.js, Bootstrap JS -->
		<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
		
	</body>
	
</html>