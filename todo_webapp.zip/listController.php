<?php
	
	class listController {
		
		private $id;
		
		private $uid;
		
		private $db;
		
		private $pwd;
		
		private $items;
		
		private $itemsSortedAsc;
		
		private $itemsSortedDesc;
		
		private $itemsComplete;
		
		private $isSortedAsc;
		
		public function __construct($id, $uid, $pwd) {
			
			$this->id = $id;
			
			$this->uid = $uid;
			
			$this->pwd = $pwd;
			
			//$this->db = NEW PDO('mysql:host=localhost;dbname=todo', $uid, $pwd);
			
			$this->db = NEW PDO('mysql:host=localhost;dbname=todo', 'root', '');
		}
		
		public function getID() {
			
			return $this->id;
		}
		
		public function getUsername() {
			
			return $this->uid;
		}
		
		public function setItems() {
			
			//original data set
			$itemsQuery = $this->db->prepare("SELECT * FROM items WHERE usr = ? AND done = 0");
			
			$itemsQuery->execute(array($this->id));
			
			$this->items = $itemsQuery->rowCount() ? $itemsQuery : [];
			
			//data set sorted ascending
			$itemsQuery = $this->db->prepare("SELECT * FROM items WHERE usr = ? AND done = 0 ORDER BY due ASC");
			
			$itemsQuery->execute(array($this->id));
			
			$this->itemsSortedAsc = $itemsQuery->rowCount() ? $itemsQuery : [];
			
			//data set sorted descending
			$itemsQuery = $this->db->prepare("SELECT * FROM items WHERE usr = ? AND done = 0 ORDER BY due DESC");
			
			$itemsQuery->execute(array($this->id));
			
			$this->itemsSortedDesc = $itemsQuery->rowCount() ? $itemsQuery : [];
			
			//data set of complete items (done = 1)
			$itemsQuery = $this->db->prepare("SELECT * FROM items WHERE usr = ? AND done = 1");
			
			$itemsQuery->execute(array($this->id));
			
			$this->itemsComplete = $itemsQuery->rowCount() ? $itemsQuery : [];
		}
		
		public function getItems() {
			
			if($this->isSortedAsc == true) {
				
				return $this->itemsSortedAsc;
			}
			
			if($this->isSortedAsc == false) {
				
				return $this->itemsSortedDesc;
			}
		}
		
		public function getItemsCompleted() {
			
			return $this->itemsComplete;
		}
		
		public function addItem() {
			
			if(isset($_POST['item']) && isset($_POST['due'])) {
				
				$itemName = trim($_POST['item']);
				
				$dueDate = trim($_POST['due']);
				
				if(empty($itemName) || empty($dueDate)) {
					
					header("Location: yourlist.php?error=noinput");
				}
				
				else {
					
					$addedQuery = $this->db->prepare("INSERT INTO items (name, usr, done, due, idx) VALUES (?, ?, 0, ?, ?)");
					
					$addedQuery->execute(array($itemName, $this->id, $dueDate, $this->index));
					
					header("Location: yourlist.php?taskadded");
				}
			}
		}
		
		public function deleteItem() {
			
			if(isset($_POST['submitDelete'])) {
				
				$itemIndex = $_POST['submitDelete'];
				
				$deletedQuery = $this->db->prepare("DELETE FROM items WHERE idx = ?");
				
				$deletedQuery->execute(array($itemIndex));
				
				header("Location: yourlist.php?taskdeleted");
			}
		}
		
		public function markCompleted() {
			
			if(isset($_POST['submitComplete'])) {
				
				$itemIndex = $_POST['submitComplete'];
				
				$completeQuery = $this->db->prepare("UPDATE items SET done = 1 WHERE idx = ?");
				
				$completeQuery->execute(array($itemIndex));
				
				header("Location: yourlist.php?taskcompleted");
			}
		}
		
		public function undoCompleted() {
			
			if(isset($_POST['submitUndo'])) {
				
				$itemIndex = $_POST['submitUndo'];
				
				$undoQuery = $this->db->prepare("UPDATE items SET done = 0 WHERE idx = ?");
				
				$undoQuery->execute(array($itemIndex));
				
				header("Location: yourlist.php?taskcompleted");
			}
		}
		
		public function sortAscending() {
			
			if(isset($_POST['submitAsc'])) {
				
				$is = $_POST['submitAsc'];
				
				$this->isSortedAsc = $is;
				
				//header("Location: yourlist.php?sortascending");
			}
		}
		
		public function sortDescending() {
			
			if(isset($_POST['submitDesc'])) {
				
				$is = $_POST['submitDesc'];
				
				$this->isSortedAsc = $is;
				
				//header("Location: yourlist.php?sortdescending");
			}
		}
	}
?>