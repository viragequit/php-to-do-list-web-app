// Set the due date
var dueDate;

document.getElementById('dateInput').onchange = function() {
	
	var input = this.value;
	
	dueDate = new Date(input);
};

// Update every 1 second
var countSec = setInterval(function() {
	
	var now = new Date().getTime();
	
	var distance = dueDate - now;
	
	var days = Math.floor(distance / (1000 * 60 * 60 * 24));
	
	var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
	
	var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
	
	var seconds = Math.floor((distance % (1000 * 60)) / 1000);

	// Display result in an element with id="timer"
	document.getElementById("timer").innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";
	
	//if no date selected, zero out
	if (dueDate == null) {
		
		document.getElementById("timer").innerHTML = "0d 0h 0m 0s";
	}
	
	//if time is up, zero out
	if (distance <= 0) {
		
		clearInterval(countSec);
		
		document.getElementById("timer").innerHTML = "0d 0h 0m 0s";
	}
}, 1000);