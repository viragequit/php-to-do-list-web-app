<?php
	
	include "listController.php";
	
	session_start();
	
	if (!isset($_SESSION['loggedin'])) {
		
		header('Location: index.html');
		
		exit();
	}
	
	$controller = new listController($_SESSION['id'], $_SESSION['name'], $_SESSION['pass']);
	
	$controller->setItems();
?>

<html>
	
	<head>
		
		<title>Your List | To-Do</title>
		
		<link href='https://fonts.googleapis.com/css?family=Bebas Neue' rel='stylesheet'>
		
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
		
		<link rel="stylesheet" href="style.css">
		
	</head>
	
	<body>
		
		<hgroup>
			
			<section class="logout">
				
				<form action="logout.php">
					
					<button class="logoutbutton" type="submit" name="submit">Log out</button>
					
				</form>
				
			</section>
			
		</hgroup>
		
		<section class="yourlist">
			
			<section class="edit">
				
				<h1>Add Task</h1>
				
				<?php
					
					if(array_key_exists('submitAdd', $_POST)) {
						
						$controller->addItem();
					}
					
					if(array_key_exists('submitDelete', $_POST)) {
						
						$controller->deleteItem();
					}
					
					if(array_key_exists('submitAsc', $_POST)) {
						
						$controller->sortAscending();
					}
					
					if(array_key_exists('submitDesc', $_POST)) {
						
						$controller->sortDescending();
					}
					
					if(array_key_exists('submitComplete', $_POST)) {
						
						$controller->markCompleted();
					}
					
					if(array_key_exists('submitUndo', $_POST)) {
						
						$controller->undoCompleted();
					}
				?>
				
				<form method="post">
					
					<br/>
					
					<input type="text" name="item" placeholder="Task to do"/>
					
					<br/>
					
					<input type="date" name="due"/>
					
					<button class="listbuttonadd" type="submit" name="submitAdd">Add</button>
					
				</form>
				
			</section>
			
			<section class="view">
				
				<h1><?=$controller->getUsername()?>'s To-Do List</h1>
				
				<?php if(!empty($controller->getItems())):?>
				
				<?php foreach($controller->getItems() as $item):?>
				
				<section class="listCompleteContainer">
					
					<form method="post">
						
						<button class="listbuttoncomplete" type="submit" name="submitComplete" value=<?php echo $item['idx']?>>Complete</button>
						
					</form>
					
				</section>
				
				<section class="listNameContainer">
					
					<section>
						
						<li class="listName"><?php echo $item['name']?></li>
						
					</section>
					
				</section>
				
				<section class="listDueContainer">
					
					<section>
						
						<li class="listDue"><?php echo $item['due']?></li>
						
					</section>
					
				</section>
				
				<section class="listDeleteContainer">
					
					<form method="post">
						
						<button class="listbuttondelete" type="submit" name="submitDelete" value=<?php echo $item['idx']?>>Delete</button>
						
					</form>
					
				</section>
				
				<?php endforeach;?>
				
				<?php else:?>
				
				<h3>Your list is currently empty</h3>
				
				<?php endif;?>
				
			</section>
			
			<section class="sort">
				
				<h1>Sort List</h1>
				
				<form method="post">
					
					<br/>
					
					<button class="sortbuttonnew" type="submit" name="submitAsc" value='1'>Due Soon</button>
					
					<button class="sortbuttonold" type="submit" name="submitDesc" value='0'>Due Later</button>
					
					<br/>
					<br/>
					<br/>
					<br/>
					
				</form>
				
			</section>
			
		</section>
		
		
		
		<section class="yourlistComplete">
			
			<section class="editSpacer">
				
				<section class="timerdisplay">
					
					<h2 id="timer"></h2>
					
					<h2 class="timerlabel">Remaining Until</h2>
					
					<input type="datetime-local" id="dateInput"/>
					
					<script src="timer.js"></script>
					
				</section>
				
			</section>
			
			<section class="CompletedView">
				
				<h1>Completed Tasks</h1>
				
				<?php if(!empty($controller->getItemsCompleted())):?>
				
				<?php foreach($controller->getItemsCompleted() as $item):?>
				
				<section class="listCompleteContainer">
					
					<form method="post">
						
						<button class="listbuttonundo" type="submit" name="submitUndo" value=<?php echo $item['idx']?>>Undo</button>
						
					</form>
					
				</section>
				
				<section class="listNameContainer">
					
					<section>
						
						<li class="listName"><?php echo $item['name']?></li>
						
					</section>
					
				</section>
				
				<section class="listDueContainer">
					
					<section>
						
						<li class="listDue"><?php echo $item['due']?></li>
						
					</section>
					
				</section>
				
				<section class="listDeleteContainer">
					
					<form method="post">
						
						<button class="listbuttondelete" type="submit" name="submitDelete" value=<?php echo $item['idx']?>>Delete</button>
						
					</form>
					
				</section>
				
				<?php endforeach;?>
				
				<?php else:?>
				
				<h3>No Completed Tasks</h3>
				
				<?php endif;?>
				
			</section>
			
			<section class="sortSpacer">
				
				
				
			</section>
			
		</section>
		
	</body>
	
</html>