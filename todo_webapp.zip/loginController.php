<?php
	
	class LoginController {
		
		private $id;
		
		private $pwd;
		
		private $username;
		
		private $password;
		
		private $db;
		
		private $userlist;
		
		private $userrow;
		
		private $isTaken;
		
		private $pwdCorrect;
		
		public function __construct() {
			
			$this->db = NEW PDO('mysql:host=localhost;dbname=todo', 'root', '');
		}
		
		public function getID() {
			
			return $this->id;
		}
		
		public function getUsername() {
			
			return $this->uid;
		}
		
		public function createUser() {
			
			if(isset($_POST['user']) && isset($_POST['pass'])) {
				
				$userName = trim($_POST['user']);
				
				$pword = trim($_POST['pass']);
				
				if(empty($userName) || empty($pword)) {
					
					echo "<h4>Empty input!</h4>";
					//header("Location: index.php?error=noinput");
				}
				
				else {
					
					$usersQuery = $this->db->prepare("SELECT users_uid FROM users");
					
					$usersQuery->execute();
					
					$this->userlist = $usersQuery->rowCount() ? $usersQuery : [];
					
					foreach($this->userlist as $user) {
						
						if ($userName == $user['users_uid']) {
							
							$this->isTaken = true;
						}
					}
					
					if ($this->isTaken == true) {
						
						//header("Location: index.php?usernametaken");
						
						echo "<h4>Username is already taken!</h4>";
					}
					
					else {
						
						$this->isTaken = false;
						
						$createQuery = $this->db->prepare("INSERT INTO users (users_uid, users_pwd) VALUES (?, ?)");
						
						$createQuery->execute(array($userName, $pword));
						
						//header("Location: index.php?usercreated");
						echo "<h3>Account created successfully!</h3>";
					}
				}
			}
		}
		
		public function loginUser() {
			
			session_start();
			
			if(isset($_POST['user']) && isset($_POST['pass'])) {
				
				$userName = trim($_POST['user']);
				
				$pword = trim($_POST['pass']);
				
				if(empty($userName) || empty($pword)) {
					
					echo "<h4>Empty Input!</h4>";
					//header("Location: index.php?error=noinput");
				}
				
				else {
					
					$loginQuery = $this->db->prepare("SELECT users_id, users_pwd FROM users WHERE users_uid = ?");
					
					$loginQuery->execute(array($userName));
					
					$this->userrow = $loginQuery->rowCount() ? $loginQuery : [];
					
					foreach($this->userrow as $user) {
						
						if ($pword == $user['users_pwd']) {
							
							$this->pwdCorrect = true;
						}
					}
					
					if ($this->pwdCorrect == true) {
						
						// Create sessions
						session_regenerate_id();
						
						$_SESSION['loggedin'] = TRUE;
						
						$_SESSION['name'] = $userName;
						
						$_SESSION['id'] = $user['users_id'];
						
						$_SESSION['pass'] = $pword;
						
						header("Location: yourlist.php?loggedin");
					}
					
					else {
						
						$this->pwdCorrect = false;
						
						//header("Location: index.php?incorrectinfo");
						echo "<h4>Incorrect username or password!</h4>";
					}
				}
			}
		}
	}
?>